# Rune CE / Bygay Archive
Welcome! This is the archive for the most recent versions of bygay/rune ce as rune has annouced they will be moving away from ce and onto external.
# NOTICE: I DO NOT HAVE ANY CLUE IF THE VERSIONS WILL BE DETECTED
